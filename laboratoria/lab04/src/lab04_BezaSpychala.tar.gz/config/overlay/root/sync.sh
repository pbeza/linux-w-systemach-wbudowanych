#!/bin/sh
SRC=/root/photos
DEST=/tmp
#DEST=root@127.0.0.1:/tmp
rsync -a --remove-source-files $SRC $DEST