#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright 2011 Hunter Lang
#
# MIT Liscence
import os.path
import os
import subprocess
import tornado.httpserver
import tornado.ioloop
import tornado.options
import tornado.web
import tornado.template as template
from tornado.options import define, options

define("port", default=8888, help="run on the given port", type=int)
static_path = "static"

class Application(tornado.web.Application):
    def __init__(self):
        handlers = [
			(r"/", StatusHandler),
			(r"/undefined", ErrorHandler),
			(r"/logout", LogoutHandler),
			(r"/streaming", StreamingHandler),
			(r'/(.*)', tornado.web.StaticFileHandler, {'path': static_path})
        ]
        
        settings = dict(
            static_path=os.path.join(os.path.dirname(__file__), "static"),
	    cookie_secret="__TODO:_GENERATE_YOUR_OWN_RANDOM_VALUE_HERE__",
        )
        tornado.web.Application.__init__(self, handlers, **settings) 

class StatusHandler(tornado.web.RequestHandler):
    @tornado.web.asynchronous
    def get(self):
	if self.get_current_user() is None:
	    self.render('static/login.html')
        else:
	    result = subprocess.check_output("ps -ef | grep ffserver", shell=True)
	    serverOn = len(result.splitlines()) > 2
	    self.render('static/index.html', status=serverOn)

    def post(self):
	username = self.get_argument("login", "")
        password = self.get_argument("password", "")
        auth = (username == "admin" and password == "admin1")
        if auth:
            self.set_current_user(username)
            self.redirect(self.get_argument("next", u"/"))
        else:
            error_msg = u"?error=" + tornado.escape.url_escape("Login incorrect.")
            self.redirect(u"/" + error_msg)
    	self.redirect("/")

    def set_current_user(self, user):
        if user:
            self.set_secure_cookie("user", tornado.escape.json_encode(user))
        else:
            self.clear_cookie("user")

    def get_current_user(self):
        user_json = self.get_secure_cookie("user")
        if user_json:
            return tornado.escape.json_decode(user_json)
        else:
            return None



class LogoutHandler(tornado.web.RequestHandler):
    @tornado.web.asynchronous
    def get(self):
	self.clear_cookie("user")
	self.redirect("/")

class StreamingHandler(tornado.web.RequestHandler):
    @tornado.web.asynchronous
    def get(self):
	self.redirect("/")

    def post(self):
	action = self.get_argument("action", "")
	print("Action: " + action)
	if action == "on":
	    self.start_streaming()
	else:
	    self.stop_streaming()
	self.redirect("/")

    def start_streaming(self):
	os.system("/etc/init.d/photos stop")
	os.system("/etc/init.d/ffserver start")

    def stop_streaming(self):
	os.system("/etc/init.d/ffserver stop")
	os.system("/etc/init.d/photos start")

class ErrorHandler(tornado.web.RequestHandler):
	@tornado.web.asynchronous
	def get(self):
		self.redirect('/')
def main():
    tornado.options.parse_command_line()
    http_server = tornado.httpserver.HTTPServer(Application(), xheaders=True)
    http_server.listen(options.port)
    tornado.ioloop.IOLoop.instance().start()
if __name__ == "__main__":
    main()
