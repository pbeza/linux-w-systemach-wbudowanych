#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright 2011 Hunter Lang
#
# MIT Liscence
import os.path
import os
import tornado.httpserver
import tornado.ioloop
import tornado.options
import tornado.web
import tornado.template as template
import base64
from tornado.options import define, options
define("port", default=8888, help="run on the given port", type=int)
filepath="/sd3"

def _checkAuth(login, password):
    if login != 'user' or password != 'linsw':
	return False
    return True

def require_basic_auth(handler_class):
    def wrap_execute(handler_execute):
        def require_basic_auth(handler, kwargs):
            auth_header = handler.request.headers.get('Authorization')
            if auth_header is None or not auth_header.startswith('Basic '):
                handler.set_status(401)
                handler.set_header('WWW-Authenticate', 'Basic realm=Restricted')
                handler._transforms = []
                handler.finish()
                return False
            auth_decoded = base64.decodestring(auth_header[6:])
            login, password = auth_decoded.split(':', 2)
            auth_found = _checkAuth(login, password)
            if auth_found is None:
                handler.set_status(401)
                handler.set_header('WWW-Authenticate', 'Basic realm=Restricted')
                handler._transforms = []
                handler.finish()
                return False
            else:
                handler.request.headers.add('auth', auth_found)
 
            return True


        def _execute(self, transforms, *args, **kwargs):
            if self.request.method != 'GET' and not require_basic_auth(self, kwargs):
                return False
            return handler_execute(self, transforms, *args, **kwargs)
        return _execute

    handler_class._execute = wrap_execute(handler_class._execute)
    return handler_class

class Application(tornado.web.Application):
    def __init__(self):
        handlers = [
			(r"/", IndexHandler),
			(r"/get/([A-Za-z0-9\_\.\-]+)", UploadHandler),
			(r"/undefined", ErrorHandler),
        ]
        
        settings = dict(
            static_path=os.path.join(os.path.dirname(__file__), "static"),
        )
        tornado.web.Application.__init__(self, handlers, **settings) 

@require_basic_auth
class IndexHandler(tornado.web.RequestHandler):
    @tornado.web.asynchronous
    def get(self):
		items = []
		for filename in os.listdir(filepath + "/"):
			if os.path.isfile(os.path.join(filepath, filename)):
				items.append(filename)
		self.render('static/index.html', items=items)
    def post(self):
	if self.request.headers.get('auth') != True:
            raise tornado.web.HTTPError(401, "Invalid username and password for HTTP basic authentication")
    	file_content = self.request.files['datafile'][0]['body']
    	file_name = self.request.files['datafile'][0]['filename']
    	x = open(filepath + "/" + file_name, 'w')
    	x.write(file_content)
    	x.close()
    	self.redirect("/")

class UploadHandler(tornado.web.RequestHandler):
	@tornado.web.asynchronous
	def get(self, filename):
		x = open(filepath + "/" + filename)
		self.set_header('Content-Type', 'text/csv')
		self.set_header('Content-Disposition', 'attachment; filename=' + filename)
		self.finish(x.read())
class ErrorHandler(tornado.web.RequestHandler):
	@tornado.web.asynchronous
	def get(self):
		self.redirect('/')
def main():
    tornado.options.parse_command_line()
    http_server = tornado.httpserver.HTTPServer(Application(), xheaders=True)
    http_server.listen(options.port)
    tornado.ioloop.IOLoop.instance().start()
if __name__ == "__main__":
    main()
